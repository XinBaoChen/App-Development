import React from 'react'
import HemisphereDisplay from './components/HemisphereDisplay'
import { BrowserRouter, Routes, Route } from 'react-router-dom'
// import About from './components/about'
import Home from './components/home'
import Contact from './components/contact'
// import Form from './components/Form'
import NavBar from './components/navbar'
import Geolocation from './components/Geolocation'
// import Search_Input from './components/Searchinput'
// import Images__List from './components/ImageList'
import Search from './components/search'
const App = function(){
    return(
        <div className='App'>
           <BrowserRouter>
            <Routes>
                {/* nested route */}
              <Route path='/' element={<NavBar/>}>
                <Route index element ={<Home/>} />
                <Route path='/geolocation' element={<Geolocation/>} />
                <Route path='/search' element={<Search/>} />
                <Route path='/contact' element={<Contact/>} /> 
              </Route>
            </Routes>
           </BrowserRouter>
        </div>
    )
}
export default App

