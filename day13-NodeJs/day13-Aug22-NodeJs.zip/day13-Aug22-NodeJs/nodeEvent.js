const events = require("events")
const util = require("util")

const teams = function(name){
    this.name = name

}
//eventEmiiter will inherent any teams in the constructor
util.inherits(teams,events.EventEmitter)

const Barcelona = new teams('Barcelona')
const Milan = new teams("Milan")

//save each constructor in an array
const teamArray = [Barcelona, Milan]

//print team using foreach loop
teamArray.forEach(t => {
    t.on('nation',function(n){
        console.log(t.name + ' is ' + n + ' soccer club')
    })
});

//emit the eventEmitter
Milan.emit("nation", 'Italian')
Barcelona.emit("nation","Spain")


//inhernece module
//example of events
const eventEmitter = new events.EventEmitter

eventEmitter.on('test',function(a){
    console.log(a)
})

eventEmitter.emit('test','Event in NodeJS')