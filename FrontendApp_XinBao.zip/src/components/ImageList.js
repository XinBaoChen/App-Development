import React from 'react';

const Images_List = function(props) {
  const images = props.images.map((image) => {
    return (
      <img
        key={image.id}
        src={image.url}
        alt='images'
        style={{ width: '200px', height: '200px' }}
      />
    );
  });

  return (
    <div>
      <p>My Images List using Pexels Api</p>
      <div style={{ display: 'flex', flexWrap: 'wrap' }}>{images}</div>
    </div>
  );
};

export default Images_List;