
import React from 'react';
import { Outlet, Link } from 'react-router-dom';
import { Dropdown } from 'semantic-ui-react';

const Navbar = function() {
  const options = [
    { key: 'home', text: 'Home', value: '/' },
    { key: 'search', text: 'Image Searching', value: '/search' },
    { key: 'contact', text: 'Contact', value: '/contact' },
    { key: 'geolocation', text: 'Geolocation', value: '/geolocation' },
  ];

  return (
    <>
      <nav className='ui raised very padded segment'>
        <a className='ui teal inverted segment' href='https://github.com/XinBaoChen'>
          ReactJS Project
        </a>
        <div className='ui right floated header'>
          <Dropdown
            text='Menu'
            options={options}
            simple
            item
            onChange={(event, data) => {
              window.location.href = data.value;
            }}
          />
        </div>
      </nav>
      <Outlet />
    </>
  );
};

export default Navbar;