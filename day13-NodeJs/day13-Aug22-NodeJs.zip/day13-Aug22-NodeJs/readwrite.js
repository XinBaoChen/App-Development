const fs = require("fs")


fs.rmdirSync("newDir")
fs.mkdirSync("newDir")

fs.mkdir("images",function(e){
    if(e){
        console.log(e)
    }
    console.log("images directory created successfully!")
})

//async comes last
//create a file using writeFileSync()
let fileContent = "This fil has three names: \n1. Peter \n 2.John \n 3. Jason  "
    fs.writeFileSync("write.txt",fileContent,"utf-8")

//create a file using writeFile
let msg = "Welcome to nodejs I/O files"
fs.writeFile("msg.txt",msg,'utf-8',function(e){
    if(e){
        console.log(e)
    }
})

//append infomation to an existing file
let addNames = "\n4. George \n 5. Anna"
fs.appendFile("write.txt",addNames,'utf-8',function(error){
    if(error){
        console.log(error)
    }
})
//remove file
fs.unlink("msg.txt",function(e){
    if(e){
        console.log(e)
    }
})
//asynchronous read module
console.log("Line before readFileSyn")
  fs.readFile("readme.txt",'utf-8', function(error, data){
    console.log("\n\n----- asyn read file ----")
    console.log(data)
})
console.log("Line after ReadFile")
let sum = 5+ 20
console.log(`Sum = ${sum}`)


//synchronous read module
console.log("\nLine before readFileSyn")
let fileRead =  fs.readFileSync("readme.txt",'utf-8')
console.log(fileRead)

console.log("Line after readFileSyn")