import React from 'react'
import axios from 'axios'
import Search_Input from './Searchinput'
import Images__List from './ImageList'

class Search extends React.Component{

    //set a state to store the response images in an array
    state = {images: []}

   onSearchSubmit = async(entry) => {
    // https://pixabay.com/api/?key=38740922-8e17a10d46592304a386ec6d0&q=${entry}&image_type=photo
       const response = await axios.get(`https://pixabay.com/api/?key=38740922-8e17a10d46592304a386ec6d0&q=${entry}&image_type=photo`)
        //set states to collect and transfer images
        this.setState({images:response.data.hits})
   }
    render(){
        return(
                    <div className='ui container' style={{marginTop: '2em'}}>
                        <h1 className='ui title' style={{textAlign:'center',color:'blue' }}>Welcome to image search App</h1>
                        <Search_Input onSearchSubmit={this.onSearchSubmit}/>
                        <p>There are {this.state.images.length}</p>
                        <Images__List images={this.state.images}/>
                        
                    </div>
                )
            }
 }
export default Search


//searchinput.js
import React from 'react'

class Search_Input extends React.Component{
    // onInputChange(event){
    //     let s = event.target.value
    //     console.log(s) //test
    // }
    //replace with an inline function onChanege


    //IMPORTANT onSubmit form
    //initalize state as an empty string 
    state = { entry: ''}
    //call onSubmit method when pressed enter
    onSubmit = (event) =>{
        event.preventDefault()
        this.props.onSearchSubmit(this.state.entry)
    }
    render(){
        return(
            <div className='ui segment' style={{margin:'2%'}}>
                <form className='ui form' onSubmit={this.onSubmit}>
                    <div className='ui field'>
                        <div className='ui massive icon input'>
                            <input type='text' placeholder='Type your search...'
                            onChange={(event)=>{this.setState({entry:event.target.value})}}
                            value={this.state.entry}
                            />
                            <i className='ui icon search'></i>
                        </div>
                    </div>
                </form>
                
            </div>
        )
    }
}
export default Search_Input
