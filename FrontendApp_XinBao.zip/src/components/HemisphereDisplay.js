import React from 'react'
import souther from './southern-hemisphere.jpg'
import nothern from './north-hemisphere.jpg'
import Ecuator from './Ecuadorian_Line.png'

const HemisphereDisplay = (props) => {
        const HemisphereResult = props.latitude
        let userLocataion = ''
        let picture = ''
        if(HemisphereResult >= 0){
            userLocataion = 'Northern Hemisphere!'
            picture = nothern
        }
        else if(HemisphereResult < 0){
            userLocataion = "Southern Hemisphere!"
            picture = souther
        }
        else{
            userLocataion = "Ecuadorian Line!"
            picture = Ecuator
        }

        
        return(
            <div style={{border: "1px solid black", padding: "10px", margin: "10px"}}>
            <p style={{border: "1px solid black", padding: "5px", margin: "5px"}}>Welcome to HemisphereDisplay</p>
            <p style={{border: "1px solid black", padding: "5px", margin: "5px"}}>You are at <span style={{border: "1px solid black", padding: "5px", margin: "5px"}}>{userLocataion}</span></p>
            <img src={picture} style={{width: "30%", border: "1px solid black", padding: "5px", margin: "5px"}}/>
        </div>
        )
    }

export default HemisphereDisplay;