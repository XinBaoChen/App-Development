const user = require("./mod")

console.log(user.helper("Peter"))
console.log(user.id(14))
console.log(user.email("xinbaochen321@gmail.com"))

function callColor(innerFunction){
    innerFunction()
}
let color  = function(){
    console.log("Passing a function")
}
console.log(callColor(color))

// const timer = setInterval(() => {
//     count += 2
//     console.log(`counting = ${count} seconds`)
//     if(count == 10){
//         clearInterval(timer)
//     }
// },2000);

//global objects
// setTimeout(()=>{
//     console.log("Welcome to nodeJS")
// },3000)

//console module
// console.warn("Warning error in the code")
// console.error("Error")
// console.trace("Trace the code below")

