
import React from 'react';
import Search from './searchPic.webp'
import Contact from './Contact-us.png'
import Geolocation from './geolocation-feature.png'
const Home = function(){
    return(
        <div className='ui raised very padded text container' style={{marginTop: "3em"}}>
            <div className="card-container">
                <div className="card">
                    <img src= {Search} alt="Image 1" />
                    <p className="title">Image Searcher</p>
                    <p className="description">Searcher is a ReactJS application that utilizes Pexels API and AJAX to search for images </p>
                </div>
                <div className="card">
                    <img src={Contact} alt="Image 2" />
                    <p className="title">Contact Us</p>
                    <p className="description">The Contact Us page provides a platform for users to reach out and communicate with the website or business. It typically includes a contact information to facilitate inquiries, feedback, or support requests. </p>
                </div>
                <div className="card">
                    <img src={Geolocation} alt="Image 3" />
                    <p className="title">Geolocation</p>
                    <p className="description">Geolocation is a feature that can determine the hemisphere you are in based on your geographical coordinates. It provides information about whether you are located in the northern or southern hemisphere.</p> 
                </div>
            </div>
        </div>
    )
}

export default Home;