import React from 'react'
import axios from 'axios'
import Search_Input from './Searchinput'
import Images_List from './ImageList'
import { createClient } from 'pexels';

class Search extends React.Component {
    state = {
      images: [],
    };
  
    onSearchSubmit = async (entry) => {
        const query = `${entry}`;
        const client = createClient('lJLOeUSSctcHNpcalZrKlSuczl9gnRJfarzbx76Vb4sQ2wIjjJERYHWq');
      
        client.photos.search({ query, per_page: 20 })
          .then(response => {
            const images = response.photos.map(photo => ({
              id: photo.id,
              url: photo.src.large2x, // or any other size you prefer
            }));
            this.setState({ images: images });
          })
          .catch(error => {
            console.error('Error:', error);
          });
      };
  
    render() {
      return (
        <div className='ui container' style={{ marginTop: '2em' }}>
          <h1 className='ui title' style={{ textAlign: 'center', color: 'blue' }}>Welcome to the image search App</h1>
          <Search_Input onSearchSubmit={this.onSearchSubmit} />
          <p>There are {this.state.images.length} images</p>
          <Images_List images={this.state.images} />
        </div>
      );
    }
  }

export default Search